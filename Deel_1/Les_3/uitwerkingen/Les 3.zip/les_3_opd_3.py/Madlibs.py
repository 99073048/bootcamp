


woord_1 = "mooie"
stad_1 = "Rotterdam"
naam_1 = "Jayden"
Woord_3 = "kledingwinkel"
woord_4 = "verkoper"
woord_5 = "jas"
woord_6 = "parkje"
woord_zin_7 = "Voetbal zaten te spelen"

print ( "Het was een " + woord_1 + " dag in " + stad_1 + ". " + naam_1 + " liep door de straten, op zoek naar een " + Woord_3 + ". Plotseling zag " + naam_1 + " een " + woord_4 + " die een " + woord_5 + " verkocht. " + naam_1 + " besloot om het te kopen en liep verder. Toen " + naam_1 + " bij een " + woord_6 + " kwam, zag hij/zij een groep mensen die " + woord_zin_7 + ". " + naam_1 + " besloot om mee te doen en had de tijd van zijn/haar leven.")


