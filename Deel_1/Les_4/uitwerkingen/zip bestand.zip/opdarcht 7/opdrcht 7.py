
print( (431 / 100) * 100 )

# Wat denk je dat eruit komt? En test het daarna eens!

# Als eerst woord het variabel 431 gedeeld door 100 wat 4,31 word en vervolgens word vermenigvuldigt door 100 wat op 430,99999 komt 


# Wat gebeurt hier? Schrijf dit op als commentaar!

