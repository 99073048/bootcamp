# Opdracht 5:
# Schrijf een programma met twee variabelen.
# Geef de eerste variabele de waarde 25 en de tweede 0.
# Deel variabele een door variabele twee. 
# Wat gebeurt er? 

a= 25

b= 0

print( a/b )