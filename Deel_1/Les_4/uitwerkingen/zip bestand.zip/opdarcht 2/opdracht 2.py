print( 5*2 -3+4/2 )
print( 5*2 - 3+4 / 2 )
#Krijg je nu dezelfde uitkomst? 

#Ja

#Vervolgens de volgende 2: 
print( (5*2) - (3+4) /2 )
print( ((5*2) -(3+4)) / 2 )


#Vreemd, dezelfde getallen. Kun je de uitkomst verklaren? 

# In Berekening 1 wordt eerst de deling uitgevoerd en daarna de aftrekking, terwijl in Berekening 2 de aftrekking binnen haakjes eerst wordt berekend en vervolgens de deling wordt uitgevoerd.