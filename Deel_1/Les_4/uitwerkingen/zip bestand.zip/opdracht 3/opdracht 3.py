het_getal_225 = " Jevayro "


print ("Hallo" + het_getal_225," ik leer nu programmeren.")
 # Ja het werkt nog 
 