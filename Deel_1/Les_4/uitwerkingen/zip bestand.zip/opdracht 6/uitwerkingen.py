print  ( (2*3 /4 + (5 -6/7) *8 ) ) # We verwachten: 34.642857142857146

print ( (((12*13 /14) + (15 -16)) /17) *18 ) # We verwachten: 199.5126050420168

# In de eerste uitdrukking (5 - 6 / 7) moeten haakjes worden toegevoegd om ervoor te zorgen dat de aftrekking correct wordt uitgevoerd 
# voordat deze wordt vermenigvuldigd met 8.


# In de tweede uitdrukking (15 - 16) moet ook een paar haakjes worden toegevoegd om de aftrekking eerst uit te voeren
#  voordat deze wordt gedeeld door 17. Hierdoor wordt de juiste volgorde van bewerkingen gehandhaafd.