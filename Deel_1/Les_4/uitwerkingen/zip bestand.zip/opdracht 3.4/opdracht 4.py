eigen_naam = " Jevayro "


print("Hallo" + eigen_naam," ik leer nu programmeren.")
