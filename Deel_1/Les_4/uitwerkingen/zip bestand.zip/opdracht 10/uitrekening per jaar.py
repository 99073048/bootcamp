seconden_per_minuut= 60
Seconden_per_uur= 60*seconden_per_minuut
seconden_per_dag= 24* Seconden_per_uur

#aantal dagen in een jaar
Dagen_per_jaar= 365

# aantal seconden in een jaar

seconden_per_jaar= Dagen_per_jaar*seconden_per_dag


print ( f" er zitten {seconden_per_jaar} seconden in een jaar." )