

#Kun je de uitkomst verklaren? 

#Operators zijn de hulprekenmiddelen die helpen bij het uitrekenen


print( 15+4 )

print( 15-4 )

print( 15*4 )

print( 15/4 )

print( 15//4 )

print( 15**4 )


print( 15%4 )


